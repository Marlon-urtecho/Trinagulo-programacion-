package par_impar;
import java.util.Scanner;
public class calculandopar_impar {

	public static void main(String[] args) {
		
		// Leyendo los datos ingresados 
		
		Scanner teclado = new Scanner (System.in);

	int n_1;
	
	System.out.println("Escriba el numero:");
	n_1=teclado.nextInt();
	
	
	if (n_1%2==0) {
	
		System.out.println("Este numero es par");
	
	}
	
	else {
		
		System.out.println("Este numero es impar");
		
	}
	
	
	
	
	
	}

}
