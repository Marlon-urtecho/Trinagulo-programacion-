/**
 * 
 */
/**
 * @author User
 *
 */
module practicas_clase {
}