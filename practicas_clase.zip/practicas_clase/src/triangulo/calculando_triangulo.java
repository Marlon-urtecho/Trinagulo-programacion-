package triangulo;
import java.util.Scanner;
public class calculando_triangulo {

	public static void main(String[] args) {
		
		//calculando la entrada del usuario
		

		Scanner teclado = new Scanner (System.in);
		
		int a = 0 , b = 0 , c = 0 ;
		
		do {
			System.out.println("ingrese el primer lado:");
			a =teclado.nextInt();
			
			System.out.println("ingrese el segundo lado:");
			b =teclado.nextInt();
			
			System.out.println("ingrese el tercer lado:");
			c =teclado.nextInt();
		
		}
		 while (a>0 || b <= 0 || c <= 0);
		
		//validando las condisionales 
		
		if (a==b && b==c && b!=c) {
			System.out.println("Este tringulo es Equilatero");
		
		}
		
		else if (a==b && a==c && b != c  ) {
		System.out.println("Este tringulo es Isosele");
	    }
		
	    else  {
	    
	    	System.out.println("Este tringulo es Escaleno");
	    }
	    
		
		
	}

}
